import hashlib, secrets
from datetime import date
from fastapi import Request, HTTPException, status
from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired
from pwdlib import PasswordHash
from .config import settings

serializer = URLSafeTimedSerializer(settings.secret_key, salt="erkevideo-admin")
password_hash = PasswordHash.recommended()

def verify_password(password: str, hashed: str) -> bool:
    try:
        return password_hash.verify(password, hashed)
    except Exception:
        return False

def make_session(username: str, csrf: str) -> str:
    return serializer.dumps({"username": username, "csrf": csrf})

def read_session(token: str) -> dict:
    try:
        return serializer.loads(token, max_age=60 * 60 * 12)
    except (BadSignature, SignatureExpired):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Unauthorized")

def require_admin(request: Request) -> dict:
    token = request.cookies.get("erke_admin")
    if not token:
        raise HTTPException(status_code=401, detail="Unauthorized")
    return read_session(token)

def csrf_ok(request: Request, session: dict):
    token = request.headers.get("X-CSRF-Token")
    if not token or not secrets.compare_digest(token, session.get("csrf", "")):
        raise HTTPException(status_code=403, detail="CSRF validation failed")

def client_key(request: Request) -> str:
    # Raw IP is never persisted; this short-lived key is only for anti-spam.
    ip = request.client.host if request.client else "unknown"
    return hashlib.sha256(f"{settings.secret_key}:{ip}".encode()).hexdigest()
