import json, os, subprocess, uuid, shutil
from pathlib import Path
from fastapi import HTTPException, UploadFile
from .config import VIDEO_DIR, THUMB_DIR, settings

ALLOWED = {
    "video/mp4": ".mp4",
    "video/webm": ".webm",
    "video/quicktime": ".mov",
}
MAX_BYTES = settings.max_video_size_mb * 1024 * 1024

def ensure_dirs():
    VIDEO_DIR.mkdir(parents=True, exist_ok=True)
    THUMB_DIR.mkdir(parents=True, exist_ok=True)

def safe_public_id() -> str:
    return uuid.uuid4().hex[:12]

def inspect_and_thumbnail(video_path: Path, thumb_path: Path) -> float:
    try:
        cmd = ["ffprobe", "-v", "error", "-show_entries", "format=duration",
               "-of", "default=noprint_wrappers=1:nokey=1", str(video_path)]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30, check=True)
        duration = float(result.stdout.strip() or 0)
        thumb_cmd = ["ffmpeg", "-y", "-ss", str(min(2, max(0, duration / 2))),
                     "-i", str(video_path), "-frames:v", "1", "-vf", "scale=640:-2",
                     str(thumb_path)]
        subprocess.run(thumb_cmd, capture_output=True, timeout=60, check=True)
        return max(0.0, duration)
    except (subprocess.SubprocessError, ValueError, FileNotFoundError) as exc:
        raise HTTPException(400, "Видео өңделмеді. Файлды қайта тексеріңіз.") from exc

async def save_upload(upload: UploadFile):
    if upload.content_type not in ALLOWED:
        raise HTTPException(400, "Тек MP4, WebM немесе MOV файлдары қабылданады.")
    public_id = safe_public_id()
    ext = ALLOWED[upload.content_type]
    path = VIDEO_DIR / f"{public_id}{ext}"
    thumb = THUMB_DIR / f"{public_id}.jpg"
    total = 0
    try:
        with path.open("wb") as out:
            while chunk := await upload.read(1024 * 1024):
                total += len(chunk)
                if total > MAX_BYTES:
                    raise HTTPException(413, f"Файл көлемі {settings.max_video_size_mb} MB-тан аспауы керек.")
                out.write(chunk)
        if total == 0:
            raise HTTPException(400, "Бос файл жүктеуге болмайды.")
        duration = inspect_and_thumbnail(path, thumb)
        return public_id, path, thumb, duration
    except Exception:
        path.unlink(missing_ok=True)
        thumb.unlink(missing_ok=True)
        raise

def remove_files(storage_path: str, thumbnail_path: str):
    Path(storage_path).unlink(missing_ok=True)
    Path(thumbnail_path).unlink(missing_ok=True)
