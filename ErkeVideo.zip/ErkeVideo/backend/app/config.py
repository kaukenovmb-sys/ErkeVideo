from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict

BASE_DIR = Path(__file__).resolve().parents[1]

class Settings(BaseSettings):
    database_url: str = "postgresql+psycopg2://erkvideo:erkvideo@db:5432/erkevideo"
    secret_key: str = "change-me"
    admin_username: str = "admin"
    admin_password_hash: str = ""
    max_video_size_mb: int = 500
    upload_dir: str = str(BASE_DIR / "uploads")
    allowed_origins: str = "http://localhost:5173"
    environment: str = "development"
    rate_limit_per_minute: int = 20

    model_config = SettingsConfigDict(env_file=".env", case_sensitive=False, extra="ignore")

settings = Settings()
UPLOAD_DIR = Path(settings.upload_dir)
VIDEO_DIR = UPLOAD_DIR / "videos"
THUMB_DIR = UPLOAD_DIR / "thumbnails"
