from getpass import getpass
from pwdlib import PasswordHash
p=PasswordHash.recommended()
print(p.hash(getpass("New admin password: ")))
