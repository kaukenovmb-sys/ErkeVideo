from datetime import datetime
from pydantic import BaseModel, Field, ConfigDict

class VideoOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    public_id: str
    title: str
    description: str
    duration: float
    views: int
    status: str
    created_at: datetime
    thumbnail_url: str
    video_url: str

class PaginatedVideos(BaseModel):
    items: list[VideoOut]
    page: int
    per_page: int
    total: int

class ReportIn(BaseModel):
    reason: str = Field(pattern="^(Inappropriate content|Copyright|Spam|Other)$")

class ReportOut(BaseModel):
    id: int
    video_id: int
    public_id: str
    title: str
    reason: str
    status: str
    created_at: datetime

class AdminLogin(BaseModel):
    username: str
    password: str

class StatusIn(BaseModel):
    status: str = Field(pattern="^(visible|hidden)$")
