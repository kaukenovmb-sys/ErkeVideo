from datetime import datetime, timezone
from pathlib import Path
from fastapi import APIRouter, Depends, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse
from sqlalchemy import func, or_
from sqlalchemy.orm import Session
from slowapi import Limiter
from slowapi.util import get_remote_address
from .database import get_db
from .models import Video, Report
from .schemas import VideoOut, PaginatedVideos, ReportIn
from .services import save_upload, MAX_BYTES
from .config import VIDEO_DIR, THUMB_DIR

router = APIRouter(prefix="/api")
limiter = Limiter(key_func=get_remote_address)

def to_out(v: Video) -> dict:
    return {
        "public_id": v.public_id, "title": v.title, "description": v.description,
        "duration": v.duration, "views": v.views, "status": v.status,
        "created_at": v.created_at, "thumbnail_url": f"/media/thumb/{v.public_id}",
        "video_url": f"/media/video/{v.public_id}",
    }

@router.post("/videos/upload", response_model=VideoOut)
@limiter.limit("5/hour")
async def upload_video(request: Request, file: UploadFile = File(...),
                       title: str = Form(...), description: str = Form("")):
    title = title.strip()
    description = description.strip()
    if not title or len(title) > 160 or len(description) > 5000:
        raise HTTPException(400, "Title немесе description өлшемі жарамсыз.")
    db = get_db().__next__()
    try:
        public_id, path, thumb, duration = await save_upload(file)
        v = Video(public_id=public_id, title=title, description=description,
                  filename=file.filename or "video", storage_path=str(path),
                  thumbnail_path=str(thumb), duration=duration)
        db.add(v); db.commit(); db.refresh(v)
        return to_out(v)
    finally:
        db.close()

@router.get("/videos", response_model=PaginatedVideos)
def videos(page: int = 1, per_page: int = 12, q: str = "", db: Session = Depends(get_db)):
    page=max(1,page); per_page=min(48,max(1,per_page))
    query=db.query(Video).filter(Video.status=="visible")
    if q.strip():
        term=f"%{q.strip()}%"
        query=query.filter(or_(Video.title.ilike(term), Video.description.ilike(term)))
    total=query.count()
    rows=query.order_by(Video.created_at.desc()).offset((page-1)*per_page).limit(per_page).all()
    return {"items":[to_out(v) for v in rows],"page":page,"per_page":per_page,"total":total}

@router.get("/videos/{public_id}", response_model=VideoOut)
def video(public_id: str, db: Session=Depends(get_db)):
    v=db.query(Video).filter(Video.public_id==public_id, Video.status=="visible").first()
    if not v: raise HTTPException(404,"Видео табылмады.")
    return to_out(v)

@router.post("/videos/{public_id}/view")
@limiter.limit("30/minute")
def view_video(public_id: str, request: Request, db: Session=Depends(get_db)):
    v=db.query(Video).filter(Video.public_id==public_id, Video.status=="visible").first()
    if not v: raise HTTPException(404,"Видео табылмады.")
    v.views += 1
    db.commit()
    return {"views":v.views}

@router.post("/videos/{public_id}/report")
@limiter.limit("5/minute")
def report(public_id: str, payload: ReportIn, request: Request, db: Session=Depends(get_db)):
    v=db.query(Video).filter(Video.public_id==public_id, Video.status=="visible").first()
    if not v: raise HTTPException(404,"Видео табылмады.")
    db.add(Report(video_id=v.id, reason=payload.reason)); db.commit()
    return {"message":"Шағым қабылданды"}

@router.get("/videos/{public_id}/stream")
def stream_alias(public_id: str, db: Session=Depends(get_db)):
    v=db.query(Video).filter(Video.public_id==public_id, Video.status=="visible").first()
    if not v: raise HTTPException(404,"Видео табылмады.")
    return FileResponse(v.storage_path)

@router.get("/media/video/{public_id}")
def media_video(public_id: str, db: Session=Depends(get_db)):
    v=db.query(Video).filter(Video.public_id==public_id, Video.status=="visible").first()
    if not v or not Path(v.storage_path).is_file(): raise HTTPException(404,"Видео табылмады.")
    return FileResponse(v.storage_path, media_type="video/mp4", filename=v.filename)

@router.get("/media/thumb/{public_id}")
def media_thumb(public_id: str, db: Session=Depends(get_db)):
    v=db.query(Video).filter(Video.public_id==public_id, Video.status=="visible").first()
    if not v or not Path(v.thumbnail_path).is_file(): raise HTTPException(404,"Thumbnail табылмады.")
    return FileResponse(v.thumbnail_path, media_type="image/jpeg")
