from pathlib import Path
from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from slowapi import _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from slowapi import Limiter
from slowapi.util import get_remote_address
from .config import UPLOAD_DIR, VIDEO_DIR, THUMB_DIR
from .database import Base, engine
from . import models
from .services import ensure_dirs
from .routes_public import router as public_router, limiter
from .routes_admin import router as admin_router

ensure_dirs()
Base.metadata.create_all(bind=engine)

app=FastAPI(title="ErkeVideo API", docs_url="/api/docs")
app.state.limiter=limiter
app.add_exception_handler(RateLimitExceeded,_rate_limit_exceeded_handler)

@app.middleware("http")
async def security_headers(request:Request, call_next):
    response=await call_next(request)
    response.headers["X-Content-Type-Options"]="nosniff"
    response.headers["X-Frame-Options"]="SAMEORIGIN"
    response.headers["Referrer-Policy"]="strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"]="camera=(), microphone=(), geolocation=()"
    response.headers["Content-Security-Policy"]="default-src 'self'; img-src 'self' data:; media-src 'self'; style-src 'self'; script-src 'self'; connect-src 'self'"
    return response

@app.exception_handler(Exception)
async def generic_error(request:Request, exc:Exception):
    return JSONResponse(status_code=500,content={"detail":"Серверде қате болды."})

app.include_router(public_router)
app.include_router(admin_router)

@app.get("/health")
def health(): return {"status":"ok"}

FRONTEND=Path(__file__).resolve().parents[2]/"frontend"
if FRONTEND.exists():
    app.mount("/assets",StaticFiles(directory=FRONTEND/"assets"),name="assets")
    @app.get("/{full_path:path}")
    def spa(full_path:str):
        candidate=FRONTEND/full_path
        if candidate.is_file() and not full_path.startswith("api/"): return FileResponse(candidate)
        return FileResponse(FRONTEND/"index.html")
