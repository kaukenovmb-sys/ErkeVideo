import secrets
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, Request, Response
from sqlalchemy import func, or_
from sqlalchemy.orm import Session
from .config import settings
from .database import get_db
from .models import Video, Report
from .schemas import AdminLogin, StatusIn
from .security import verify_password, make_session, require_admin, csrf_ok
from .services import remove_files

router=APIRouter(prefix="/api/admin")

@router.post("/login")
def login(payload: AdminLogin, response: Response):
    if not settings.admin_password_hash or payload.username != settings.admin_username or not verify_password(payload.password, settings.admin_password_hash):
        raise HTTPException(401,"Қате логин немесе пароль.")
    csrf=secrets.token_urlsafe(24)
    response.set_cookie("erke_admin", make_session(payload.username,csrf), httponly=True, secure=settings.environment=="production",
                        samesite="lax", max_age=43200)
    return {"ok":True,"csrf":csrf}

@router.post("/logout")
def logout(response: Response):
    response.delete_cookie("erke_admin")
    return {"ok":True}

@router.get("/me")
def me(request: Request):
    s=require_admin(request); return {"username":s["username"],"csrf":s["csrf"]}

def guard(request: Request):
    s=require_admin(request); csrf_ok(request,s); return s

@router.get("/stats")
def stats(request: Request, db: Session=Depends(get_db)):
    guard(request)
    today=datetime.now(timezone.utc).date()
    total=db.query(func.count(Video.id)).scalar() or 0
    views=db.query(func.coalesce(func.sum(Video.views),0)).scalar() or 0
    uploads=db.query(func.count(Video.id)).filter(func.date(Video.created_at)==today).scalar() or 0
    reports=db.query(func.count(Report.id)).filter(Report.status=="open").scalar() or 0
    storage=sum((__import__("pathlib").Path(v.storage_path).stat().st_size for v in db.query(Video).all() if __import__("pathlib").Path(v.storage_path).exists()),0)
    return {"total_videos":total,"total_views":views,"today_uploads":uploads,"open_reports":reports,"storage_bytes":storage}

@router.get("/videos")
def admin_videos(request: Request, page:int=1, per_page:int=20, q:str="", db:Session=Depends(get_db)):
    guard(request); page=max(1,page); per_page=min(50,max(1,per_page))
    query=db.query(Video)
    if q.strip():
        t=f"%{q.strip()}%"; query=query.filter(or_(Video.title.ilike(t),Video.public_id.ilike(t)))
    total=query.count()
    rows=query.order_by(Video.created_at.desc()).offset((page-1)*per_page).limit(per_page).all()
    return {"items":[{"id":v.id,"public_id":v.public_id,"title":v.title,"views":v.views,"status":v.status,
                      "created_at":v.created_at,"thumbnail_url":f"/media/thumb/{v.public_id}"} for v in rows],
            "total":total,"page":page,"per_page":per_page}

@router.patch("/videos/{video_id}")
def change_status(video_id:int, payload:StatusIn, request:Request, db:Session=Depends(get_db)):
    guard(request)
    v=db.query(Video).filter(Video.id==video_id).first()
    if not v: raise HTTPException(404,"Видео табылмады.")
    v.status=payload.status; db.commit()
    return {"ok":True}

@router.delete("/videos/{video_id}")
def delete_video(video_id:int, request:Request, db:Session=Depends(get_db)):
    guard(request)
    v=db.query(Video).filter(Video.id==video_id).first()
    if not v: raise HTTPException(404,"Видео табылмады.")
    remove_files(v.storage_path,v.thumbnail_path); db.delete(v); db.commit()
    return {"ok":True}

@router.get("/reports")
def reports(request:Request, db:Session=Depends(get_db)):
    guard(request)
    rows=db.query(Report).join(Video).order_by(Report.created_at.desc()).limit(200).all()
    return {"items":[{"id":r.id,"video_id":r.video_id,"public_id":r.video.public_id,"title":r.video.title,
                      "reason":r.reason,"status":r.status,"created_at":r.created_at} for r in rows]}

@router.patch("/reports/{report_id}")
def resolve_report(report_id:int, request:Request, db:Session=Depends(get_db)):
    guard(request)
    r=db.query(Report).filter(Report.id==report_id).first()
    if not r: raise HTTPException(404,"Шағым табылмады.")
    r.status="resolved"; db.commit(); return {"ok":True}
